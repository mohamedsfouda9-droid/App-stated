package com.mozakarty.app

import android.content.Intent
import android.net.Uri
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Burgundy = Color(0xFF70213A)
private val DeepRed = Color(0xFFB3263E)
private val NearBlack = Color(0xFF171316)
private val SurfaceDark = Color(0xB3261D23)
private val GlassBorder = Color(0x66F5C4D2)
private val PalePink = Color(0xFFF5E9ED)

data class Subject(val name: String, val subtitle: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
data class SavedStudyFile(val name: String, val uri: String)

private const val PREFS_NAME = "mozakarty"
private const val SAVED_FILES_KEY = "saved_study_files"

private fun loadSavedStudyFiles(context: Context): List<SavedStudyFile> {
    val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(SAVED_FILES_KEY, "[]") ?: "[]"
    return try {
        val array = org.json.JSONArray(raw)
        (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val name = item.optString("name").takeIf { it.isNotBlank() } ?: "ملف دراسي"
            val uri = item.optString("uri").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            SavedStudyFile(name, uri)
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveStudyFiles(context: Context, files: List<SavedStudyFile>) {
    val array = org.json.JSONArray()
    files.forEach { file ->
        array.put(JSONObject().put("name", file.name).put("uri", file.uri))
    }
    context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
        .putString(SAVED_FILES_KEY, array.toString()).apply()
}

private fun openStudyFile(context: Context, file: SavedStudyFile) {
    val uri = Uri.parse(file.uri)
    val mime = context.contentResolver.getType(uri) ?: "*/*"
    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { context.startActivity(Intent.createChooser(intent, "فتح ${file.name}")) }
    catch (_: Exception) { android.widget.Toast.makeText(context, "مفيش تطبيق مناسب لفتح الملف", android.widget.Toast.LENGTH_LONG).show() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MozakartyApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MozakartyApp() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("الرئيسية") }
    var selectedSubject by remember { mutableStateOf<Subject?>(null) }
    var selectedFile by remember { mutableStateOf<Uri?>(null) }
    var savedFiles by remember { mutableStateOf(loadSavedStudyFiles(context)) }
    var fileName by remember { mutableStateOf("") }
    var lessonText by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var aiEndpoint by remember { mutableStateOf(context.getSharedPreferences("mozakarty", Context.MODE_PRIVATE).getString("ai_endpoint", "") ?: "") }
    var aiBusy by remember { mutableStateOf(false) }
    var aiError by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var showLogin by remember { mutableStateOf(false) }
    var showNotice by remember { mutableStateOf(false) }

    val subjects = listOf(
        Subject("اللغة العربية", "نحو • أدب • قراءة", Icons.Default.MenuBook),
        Subject("اللغة الإنجليزية", "Grammar • Vocabulary", Icons.Default.Translate),
        Subject("التاريخ", "أحداث • شخصيات • تواريخ", Icons.Default.AccountBalance),
        Subject("البرمجة", "مفاهيم • أكواد • تطبيقات", Icons.Default.Code),
        Subject("الرياضيات", "قوانين • مسائل • تدريبات", Icons.Default.Calculate),
        Subject("مواد مسار الهندسة", "مواد المسار وملاحظاتك", Icons.Default.Engineering)
    )

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedFile = uri
            fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "ملف دراسي"
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            val savedUri = uri.toString()
            val item = SavedStudyFile(fileName.ifBlank { "ملف دراسي" }, savedUri)
            savedFiles = listOf(item) + savedFiles.filterNot { it.uri == savedUri }
            saveStudyFiles(context, savedFiles)
            selectedTab = "مكتبتي"
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = DeepRed,
            secondary = Burgundy,
            background = NearBlack,
            surface = SurfaceDark,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize().background(NearBlack),
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("مذاكرتي", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                            Text("البكالوريا المصرية • مسار الهندسة", fontSize = 11.sp, color = PalePink)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showNotice = true }) {
                            Icon(Icons.Default.NotificationsNone, "الإشعارات", tint = Color.White)
                        }
                        IconButton(onClick = { showLogin = true }) {
                            Icon(Icons.Default.AccountCircle, "الحساب", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Burgundy,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark, contentColor = Color.White) {
                    listOf(
                        "الرئيسية" to Icons.Default.Home,
                        "مكتبتي" to Icons.Default.CollectionsBookmark,
                        "تلخيص الدرس" to Icons.Default.AutoAwesome
                    ).forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == label,
                            onClick = { selectedTab = label; selectedSubject = null },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.White,
                                selectedTextColor = Color.White,
                                indicatorColor = Burgundy,
                                unselectedIconColor = PalePink,
                                unselectedTextColor = PalePink
                            )
                        )
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { filePicker.launch(arrayOf("*/*")) },
                    containerColor = DeepRed,
                    contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة كتاب أو ملف") }
            }
        ) { padding ->
            when {
                showLogin -> LoginPanel(
                    modifier = Modifier.padding(padding),
                    onClose = { showLogin = false }
                )
                showNotice -> NoticePanel(
                    modifier = Modifier.padding(padding),
                    onClose = { showNotice = false }
                )
                selectedTab == "مكتبتي" -> LibraryPanel(
                    modifier = Modifier.padding(padding),
                    files = savedFiles,
                    onChoose = { filePicker.launch(arrayOf("*/*")) },
                    onOpen = { openStudyFile(context, it) },
                    onDelete = { item ->
                        savedFiles = savedFiles.filterNot { it.uri == item.uri }
                        saveStudyFiles(context, savedFiles)
                    }
                )
                selectedTab == "تلخيص الدرس" -> SummaryPanel(
                    modifier = Modifier.padding(padding),
                    fileName = fileName,
                    lessonText = lessonText,
                    onTextChange = { lessonText = it },
                    summary = summary,
                    endpoint = aiEndpoint,
                    onEndpointChange = {
                        aiEndpoint = it
                        context.getSharedPreferences("mozakarty", Context.MODE_PRIVATE).edit().putString("ai_endpoint", it).apply()
                    },
                    busy = aiBusy,
                    error = aiError,
                    onSummarize = {
                        summary = summarizeLocally(lessonText)
                        aiError = ""
                    },
                    onAskAI = {
                        if (aiEndpoint.isBlank()) {
                            aiError = "أضف رابط خادم الذكاء الاصطناعي أولًا. راجع ملف CLOUDFLARE_SETUP_AR.md داخل المشروع."
                        } else if (lessonText.isBlank()) {
                            aiError = "اكتب سؤالك أو الصق نص الدرس أولًا."
                        } else {
                            aiBusy = true
                            aiError = ""
                            scope.launch {
                                try {
                                    summary = callAiEndpoint(aiEndpoint, lessonText)
                                } catch (e: Exception) {
                                    aiError = "لم أستطع الاتصال بالخدمة: ${e.message ?: "تحقق من الإنترنت ورابط الخادم"}"
                                } finally {
                                    aiBusy = false
                                }
                            }
                        }
                    },
                    onChooseFile = { filePicker.launch(arrayOf("*/*")) }
                )
                selectedSubject != null -> SubjectPanel(
                    modifier = Modifier.padding(padding),
                    subject = selectedSubject!!,
                    fileName = fileName,
                    onBack = { selectedSubject = null },
                    onChooseFile = { filePicker.launch(arrayOf("*/*")) }
                )
                else -> HomePanel(
                    modifier = Modifier.padding(padding),
                    subjects = subjects,
                    onSubject = { selectedSubject = it },
                    onUpload = { filePicker.launch(arrayOf("*/*")) },
                    onSummarize = { selectedTab = "تلخيص الدرس" }
                )
            }
        }
    }
}

@Composable
fun HomePanel(
    modifier: Modifier = Modifier,
    subjects: List<Subject>,
    onSubject: (Subject) -> Unit,
    onUpload: () -> Unit,
    onSummarize: () -> Unit
) {
    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Burgundy.copy(alpha = 0.72f))
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أهلًا بيك في مذاكرتي 👋", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("حوّل الدروس الطويلة إلى نقاط وأسئلة تساعدك تراجع بذكاء.", color = PalePink)
                Button(onClick = onSummarize, colors = ButtonDefaults.buttonColors(containerColor = DeepRed)) {
                    Icon(Icons.Default.AutoAwesome, null)
                    Spacer(Modifier.width(8.dp))
                    Text("ابدأ تلخيص درس")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("المواد الدراسية", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("الصف الثاني • الهندسة", color = PalePink, fontSize = 11.sp)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(370.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(subjects) { subject ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(164.dp).clickable { onSubject(subject) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (subject.name == "اللغة العربية" || subject.name == "البرمجة") Burgundy.copy(alpha = 0.68f) else SurfaceDark
                    ),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)
                ) {
                    Column(
                        Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(subject.icon, null, tint = Color(0xFFFFC4D2), modifier = Modifier.size(30.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(subject.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(subject.subtitle, color = PalePink, fontSize = 10.sp)
                        }
                        Text("افتح المادة  ›", color = Color(0xFFFFC4D2), fontSize = 11.sp)
                    }
                }
            }
        }
        OutlinedButton(onClick = onUpload, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.UploadFile, null)
            Spacer(Modifier.width(8.dp))
            Text("رفع كتاب أو ملف من الجهاز")
        }
        Text("ملاحظة: الكتب المعروضة تُضاف من ملفاتك أو من مصادر رسمية متاحة.", color = PalePink, fontSize = 11.sp)
    }
}

@Composable
fun SubjectPanel(
    modifier: Modifier,
    subject: Subject,
    fileName: String,
    onBack: () -> Unit,
    onChooseFile: () -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, null); Text(" رجوع للمواد") }
        Icon(subject.icon, null, tint = Color(0xFFFFB7C9), modifier = Modifier.size(48.dp))
        Text(subject.name, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("مكتبة المادة", color = PalePink)
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("كتب المادة وملفاتك", fontWeight = FontWeight.Bold)
                Text(if (fileName.isBlank()) "لسه مفيش ملفات مضافة هنا. ارفع كتابًا للبدء." else "آخر ملف تم اختياره: $fileName", color = PalePink)
                Button(onClick = onChooseFile, colors = ButtonDefaults.buttonColors(containerColor = Burgundy)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة كتاب أو مذكرة")
                }
            }
        }
        Text("أفكار للمراجعة", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        listOf("ملخص الدرس", "أهم التعريفات والقوانين", "أسئلة تدريبية وإجاباتها", "ملاحظاتي الشخصية").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ChevronLeft, null, tint = Color(0xFFFFB7C9))
                    Text(it)
                }
            }
        }
    }
}

@Composable
fun LibraryPanel(
    modifier: Modifier,
    files: List<SavedStudyFile>,
    onChoose: () -> Unit,
    onOpen: (SavedStudyFile) -> Unit,
    onDelete: (SavedStudyFile) -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("مكتبتي", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("الملفات المضافة هنا تُحفظ في قائمة مكتبتك على الجهاز.", color = PalePink)
        Button(onClick = onChoose, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Burgundy)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إضافة ملف إلى المكتبة")
        }
        if (files.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOpen, null, tint = Color(0xFFFFB7C9), modifier = Modifier.size(42.dp))
                    Text("مكتبتك لسه فاضية")
                    Text("اضغط إضافة ملف، واختار PDF أو صورة أو أي مستند من جهازك.", color = PalePink, textAlign = TextAlign.Center)
                }
            }
        } else {
            Text("ملفاتي (${files.size})", fontWeight = FontWeight.Bold)
            files.forEach { file ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = Color(0xFFFFB7C9), modifier = Modifier.size(30.dp))
                        Column(Modifier.weight(1f)) {
                            Text(file.name, fontWeight = FontWeight.SemiBold, maxLines = 2)
                            Text("محفوظ في المكتبة", color = PalePink, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onOpen(file) }) { Icon(Icons.Default.OpenInNew, "فتح الملف", tint = Color.White) }
                        IconButton(onClick = { onDelete(file) }) { Icon(Icons.Default.DeleteOutline, "إزالة من المكتبة", tint = Color(0xFFFFB7C9)) }
                    }
                }
            }
        }
        Text("ملاحظة: المكتبة تحفظ رابط الملف الذي اخترته من الجهاز. لا تحذف الملف الأصلي أو تنقله من مكانه، وإلا قد تحتاج إلى إضافته مرة أخرى.", fontSize = 12.sp, color = PalePink)
    }
}

@Composable
fun SummaryPanel(
    modifier: Modifier,
    fileName: String,
    lessonText: String,
    onTextChange: (String) -> Unit,
    summary: String,
    endpoint: String,
    onEndpointChange: (String) -> Unit,
    busy: Boolean,
    error: String,
    onSummarize: () -> Unit,
    onAskAI: () -> Unit,
    onChooseFile: () -> Unit
) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("سكونا AI للمذاكرة", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("اسأل عن الدرس أو اطلب تلخيصه. الاتصال الحقيقي يحتاج رابط خدمة AI آمنة.", color = PalePink)
        OutlinedTextField(
            value = endpoint,
            onValueChange = onEndpointChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("رابط خادم AI /ask") },
            placeholder = { Text("https://اسم-الخدمة.workers.dev/ask") },
            singleLine = true
        )
        OutlinedButton(onClick = onChooseFile, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(8.dp))
            Text(if (fileName.isBlank()) "اختيار ملف درس" else "الملف المختار: $fileName")
        }
        OutlinedTextField(
            value = lessonText,
            onValueChange = onTextChange,
            modifier = Modifier.fillMaxWidth().height(180.dp),
            label = { Text("اكتب سؤالك أو الصق نص الدرس") },
            placeholder = { Text("مثال: لخص الدرس، استخرج أهم النقاط، وكون 10 أسئلة بإجاباتها...") },
            shape = RoundedCornerShape(16.dp)
        )
        Button(
            onClick = onAskAI,
            modifier = Modifier.fillMaxWidth(),
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = DeepRed)
        ) {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                Spacer(Modifier.width(8.dp))
                Text("سكونا بيفكر...")
            } else {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("اسأل سكونا AI")
            }
        }
        OutlinedButton(onClick = onSummarize, modifier = Modifier.fillMaxWidth()) {
            Text("استخراج نقاط سريعة دون إنترنت")
        }
        if (error.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF51202B)), border = androidx.compose.foundation.BorderStroke(1.dp, DeepRed)) {
                Text(error, modifier = Modifier.padding(12.dp), color = Color.White)
            }
        }
        if (summary.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), border = androidx.compose.foundation.BorderStroke(1.dp, GlassBorder)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("إجابة سكونا", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFFFFC4D2))
                    Text(summary)
                }
            }
        }
        Text("مهم: اختيار الملف لا يستخرج محتواه تلقائيًا بعد؛ انسخ نص الدرس إلى المربع حاليًا. لا تضع مفتاح API في التطبيق؛ المفتاح يُحفظ سرًا في الخادم.", color = PalePink, fontSize = 11.sp)
    }
}


suspend fun callAiEndpoint(endpoint: String, prompt: String): String = withContext(Dispatchers.IO) {
    val cleanEndpoint = endpoint.trim().removeSuffix("/")
    val target = if (cleanEndpoint.endsWith("/ask")) cleanEndpoint else "$cleanEndpoint/ask"
    val connection = (URL(target).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
        setRequestProperty("Accept", "application/json")
    }
    try {
        val payload = JSONObject().put("message", prompt).toString()
        connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("HTTP $code: ${body.take(300)}")
        val json = JSONObject(body)
        json.optString("answer").ifBlank { json.optString("response") }
            .ifBlank { "وصل رد من الخادم لكن لم أجد حقل answer في الاستجابة." }
    } finally {
        connection.disconnect()
    }
}

fun summarizeLocally(input: String): String {
    val cleaned = input.trim().replace(Regex("\\s+"), " ")
    if (cleaned.isBlank()) return "اكتب أو الصق نص الدرس أولًا، ثم اضغط على زر استخراج النقاط."
    val sentences = cleaned.split(Regex("(?<=[.!؟?])\\s+|(?<=。)\\s+"))
        .map { it.trim() }
        .filter { it.length > 12 }
    val selected = sentences.take(6)
    if (selected.isEmpty()) return cleaned.take(700)
    return selected.mapIndexed { index, sentence -> "${index + 1}. $sentence" }.joinToString("\n\n")
}

@Composable
fun LoginPanel(modifier: Modifier, onClose: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onClose) { Text("رجوع") }
        Text("حسابك في مذاكرتي", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("واجهة مبدئية لتسجيل الدخول. يلزم إعداد Firebase وربط مزودي الدخول لتفعيل الحسابات فعليًا.", color = PalePink)
        Button(onClick = { }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Burgundy)) {
            Icon(Icons.Default.AccountCircle, null); Spacer(Modifier.width(8.dp)); Text("المتابعة باستخدام Google (يتطلب إعدادًا)")
        }
        OutlinedTextField(value = phone, onValueChange = { phone = it }, modifier = Modifier.fillMaxWidth(), label = { Text("رقم الهاتف مع مفتاح الدولة") }, placeholder = { Text("+20...") })
        Button(onClick = { }, modifier = Modifier.fillMaxWidth(), enabled = phone.length >= 8, colors = ButtonDefaults.buttonColors(containerColor = DeepRed)) {
            Text("إرسال رمز التحقق (يتطلب إعداد Firebase)")
        }
        Text("لا يتم إرسال رسالة أو إنشاء حساب في هذه النسخة الأولية.", color = PalePink, fontSize = 12.sp)
    }
}

@Composable
fun NoticePanel(modifier: Modifier, onClose: () -> Unit) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        TextButton(onClick = onClose) { Text("رجوع") }
        Text("الإشعارات", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Icon(Icons.Default.NotificationsActive, null, tint = Color(0xFFFFB7C9), modifier = Modifier.size(44.dp))
        Text("هنا يمكن إضافة تذكيرات المذاكرة ومواعيد المراجعة. هذه النسخة تعرض واجهة الإشعارات فقط، ولم يتم إعداد جدولة تنبيهات بعد.", color = PalePink)
    }
}
