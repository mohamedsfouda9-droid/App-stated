# إعداد تسجيل الدخول في مذاكرتي (بالعربية)

أضفنا Firebase Auth ومكتبات Google Sign-In للمشروع، ووضعنا `google-services.json` الذي أرسلته داخل مجلد `app/`.

## خطوات لازمة قبل أن يعمل تسجيل الدخول
1. افتح Firebase Console ثم مشروع `mozakarty-54bd1`.
2. من Project settings > Your apps > Android app، تأكد أن اسم الحزمة هو `com.mozakarty.app`.
3. افتح Project settings > Your apps، وأضف بصمة SHA-1 لتطبيق Android. عند البناء من GitHub Actions، أسهل طريقة للحصول على بصمة شهادة debug هي إضافة خطوة مؤقتة لتشغيل `gradle signingReport`، أو استخراجها من سجل البناء.
4. من Authentication > Sign-in method (أو Sign-in providers)، فعّل Google واحفظ.
5. إذا طلب Firebase بريد دعم، اختر بريدًا مناسبًا.
6. بعد حفظ إعداد Google، نزّل `google-services.json` مرة أخرى واستبدل الملف الموجود في `app/google-services.json`.
7. ارفع المشروع إلى GitHub وشغّل Actions. نزّل APK الجديد واختبر زر Google.

## مهم
- ملف `google-services.json` الذي أرسلته لا يحتوي حاليًا على OAuth client (`oauth_client` فارغ)، لذلك زر Google قد يعرض رسالة تطلب إكمال إعداد OAuth حتى تنفذ الخطوات أعلاه.
- تسجيل الدخول برقم الهاتف ما زال غير مفعّل في هذا الإصدار.
- مفتاح Gemini لا يوضع داخل التطبيق. سكونا AI يحتاج إعداد Worker منفصلًا وإضافة `GEMINI_API_KEY` كسرّ في إعدادات الخادم.
- لا يمكن تأكيد عمل تسجيل الدخول قبل تفعيل Google وإضافة SHA-1 وإعادة تنزيل ملف الإعدادات.
