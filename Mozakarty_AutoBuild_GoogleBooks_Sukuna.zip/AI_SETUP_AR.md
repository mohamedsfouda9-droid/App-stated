# إعداد الذكاء الاصطناعي الحقيقي

اتبع `CLOUDFLARE_SETUP_AR.md` في حزمة `Mozakarty_AI_Worker.zip` لإنشاء خدمة Cloudflare Worker وحفظ سر `GEMINI_API_KEY` فيها.
بعدها افتح شاشة سكونا AI داخل التطبيق واكتب رابط Worker في خانة رابط خادم AI. الخدمة تعمل عبر الإنترنت، بينما خيار استخراج النقاط السريعة يعمل محليًا.
لا تضع مفتاح Gemini داخل كود Android أو APK أو مستودع GitHub.
