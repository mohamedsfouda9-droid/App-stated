# ابدأ من هنا — مذاكرتي + سكونا AI

## الطريقة التي تريدها: ارفع ملف ZIP ودع GitHub يبني APK

**مهم:** GitHub لا يستطيع تشغيل Workflow من ZIP وحده إذا لم يكن ملف الـ Workflow موجودًا بالفعل في المستودع. نفّذ الإعداد الأول مرة واحدة فقط:

1. أنشئ مستودع GitHub جديدًا.
2. من المستودع اختر Add file → Create new file.
3. اكتب اسم الملف بالضبط: `.github/workflows/android.yml`
4. افتح ملف `android.yml` الموجود في هذه الحزمة وانسخ محتواه كاملًا إلى GitHub، ثم اضغط Commit changes.
5. ارفع ملف المشروع ZIP إلى جذر المستودع، ويفضل أن تسميه `Mozakarty_Sukuna_AI_Glass_Project.zip` أو `project.zip`.
6. افتح Actions. سيبدأ البناء تلقائيًا بعد رفع ZIP. بعد نجاحه افتح تشغيل الـ workflow ثم Artifacts وحمّل `mozakarty-debug-apk`.

بديل أبسط: فك ضغط مشروع Android وارفع كل محتوياته إلى جذر المستودع. نفس Workflow يدعم الحالتين.

## خدمة سكونا AI

انشر مجلد `ai-worker` كـ Cloudflare Worker، ثم أضف `GEMINI_API_KEY` كـ Secret في إعدادات Worker. لا تضع المفتاح في تطبيق Android أو في GitHub. انسخ رابط الخدمة وأضفه في شاشة سكونا AI مع المسار `/ask`.

## البحث عن الكتب عبر Google Books

بعد نشر الـ Worker، يمكنك تجربة الرابط:
`https://YOUR-WORKER.workers.dev/books?q=الهندسة`

تظهر بيانات الكتب التي يعرضها Google Books، وروابط المعاينة عند توفرها. الخدمة لا تضمن توفر كل كتب المنهج أو ملفات PDF المجانية، ويجب احترام حقوق النشر.

## محرك بحث Google العام

مسار `/search?q=...` يحتاج إعداد Google Programmable Search Engine. أضف `GOOGLE_CSE_API_KEY` و`GOOGLE_CSE_ID` كـ Secrets في Cloudflare Worker. قد تكون هناك حدود استخدام أو تكلفة حسب إعدادات حساب Google. Google Books يعمل دون هذين المفتاحين.

## تنبيهات
- إعداد تسجيل دخول Google داخل التطبيق يتطلب إعداد OAuth/Firebase منفصلًا؛ مجرد وجود حساب Google لا يربط التطبيق تلقائيًا.
- رفع PDF أو صورة لا يعني أن التطبيق يستخرج نصهما تلقائيًا؛ هذه الحزمة لا تضيف OCR أو استخراج PDF.
- لا تضع مفاتيح الخدمات داخل ملفات التطبيق أو المستودع العام.
