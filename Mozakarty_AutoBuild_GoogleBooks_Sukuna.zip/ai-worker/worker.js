export default {
  async fetch(request, env) {
    const cors = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json; charset=utf-8"
    };
    if (request.method === "OPTIONS") return new Response(null, { headers: cors });
    const url = new URL(request.url);
    const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: cors });

    if (url.pathname === "/books") {
      const q = (url.searchParams.get("q") || "البكالوريا مسار الهندسة مصر").trim();
      if (q.length > 180) return json({ error: "عبارة البحث طويلة" }, 400);
      try {
        const api = new URL("https://www.googleapis.com/books/v1/volumes");
        api.searchParams.set("q", q);
        api.searchParams.set("maxResults", "20");
        api.searchParams.set("printType", "books");
        api.searchParams.set("orderBy", "relevance");
        const res = await fetch(api.toString());
        const data = await res.json();
        if (!res.ok) return json({ error: "تعذر البحث في Google Books" }, 502);
        const items = (data.items || []).map(x => {
          const v = x.volumeInfo || {};
          return { title: v.title || "كتاب بدون عنوان", authors: v.authors || [], description: (v.description || "").slice(0, 700), pageCount: v.pageCount || null, previewLink: v.previewLink || "", infoLink: v.infoLink || "", thumbnail: v.imageLinks?.thumbnail || "", publishedDate: v.publishedDate || "" };
        });
        return json({ source: "Google Books", totalItems: data.totalItems || 0, items });
      } catch (e) { return json({ error: "خطأ أثناء البحث: " + String(e?.message || e) }, 500); }
    }

    if (url.pathname === "/search") {
      const q = (url.searchParams.get("q") || "").trim();
      if (!q) return json({ error: "أضف عبارة البحث في q" }, 400);
      if (!env.GOOGLE_CSE_API_KEY || !env.GOOGLE_CSE_ID) return json({ error: "للبحث العام أضف GOOGLE_CSE_API_KEY و GOOGLE_CSE_ID في أسرار Cloudflare. يمكنك استخدام /books بدون هذه الإعدادات." }, 503);
      try {
        const api = new URL("https://www.googleapis.com/customsearch/v1");
        api.searchParams.set("key", env.GOOGLE_CSE_API_KEY);
        api.searchParams.set("cx", env.GOOGLE_CSE_ID);
        api.searchParams.set("q", q.slice(0, 180));
        api.searchParams.set("num", "10");
        const res = await fetch(api.toString());
        const data = await res.json();
        if (!res.ok) return json({ error: data?.error?.message || "فشل بحث Google" }, 502);
        return json({ source: "Google Search", items: (data.items || []).map(x => ({ title: x.title || "", link: x.link || "", snippet: x.snippet || "" })) });
      } catch (e) { return json({ error: "خطأ أثناء البحث: " + String(e?.message || e) }, 500); }
    }

    if (url.pathname !== "/ask") return json({ error: "المسارات المتاحة: /ask و /books?q=... و /search?q=..." }, 404);
    if (request.method !== "POST") return json({ error: "استخدم POST" }, 405);
    if (!env.GEMINI_API_KEY) return json({ error: "لم يتم إعداد GEMINI_API_KEY في أسرار Cloudflare" }, 500);
    try {
      const body = await request.json();
      const message = String(body.message || "").trim();
      if (!message) return json({ error: "اكتب السؤال أولًا" }, 400);
      if (message.length > 30000) return json({ error: "النص طويل جدًا؛ أرسل جزءًا أقصر من الدرس" }, 413);
      const prompt = `أنت مساعد تعليمي عربي اسمه سكونا AI، تساعد طالب البكالوريا المصرية مسار الهندسة. أجب بالعربية الواضحة، ونظم الإجابة بعناوين ونقاط. ساعد في الشرح والتلخيص والتدريب، ولا تدّع أن الأسئلة مؤكدة في الامتحان.\n\nرسالة الطالب أو نص الدرس:\n${message}`;
      const upstream = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + encodeURIComponent(env.GEMINI_API_KEY), {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 2500 } })
      });
      const data = await upstream.json();
      if (!upstream.ok) return json({ error: data?.error?.message || "فشلت خدمة الذكاء الاصطناعي" }, 502);
      const answer = (data.candidates || []).flatMap(c => c.content?.parts || []).map(p => p.text || "").join("\n").trim();
      if (!answer) return json({ error: "لم تصل إجابة نصية من النموذج" }, 502);
      return json({ answer });
    } catch (e) { return json({ error: "تعذر معالجة الطلب: " + String(e?.message || e) }, 500); }
  }
};
